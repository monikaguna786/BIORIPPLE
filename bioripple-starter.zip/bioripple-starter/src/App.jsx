import React, { useMemo, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Activity, ArrowDownRight, ArrowRight, Atom, Bell, Check, CheckCircle2,
  ChevronDown, CircleHelp, Command, Download, FlaskConical, GitBranch,
  Lightbulb, Menu, Moon, Network, Plus, Search, Settings2, ShieldCheck,
  Sparkles, Sun, Upload, Waves, X, AlertTriangle, FileText, Microscope,
  Clock3, CircleDot, Filter, Zap, PanelLeftClose, ExternalLink, ArrowUpRight
} from 'lucide-react'

const initialExperiments = [
  { id: 'EXP-204', name: 'Culture optimization — Batch 04', type: 'Process study', date: 'Today, 09:42', status: 'Reviewed', accent: 'teal', detail: 'Growth medium composition updated; protein yield increased by 12%.' },
  { id: 'EXP-198', name: 'Protein expression baseline', type: 'Baseline study', date: 'Yesterday', status: 'Verified', accent: 'blue', detail: 'Reference expression profile from the prior protocol version.' },
  { id: 'EXP-176', name: 'Purification consistency check', type: 'Downstream process', date: 'Oct 14', status: 'Needs review', accent: 'amber', detail: 'Purification variability observed across two sample batches.' },
  { id: 'EXP-161', name: 'Cell viability time course', type: 'Validation study', date: 'Oct 11', status: 'Verified', accent: 'blue', detail: 'Cell viability remained within the expected range.' }
]

const nodes = [
  { id: 'a', x: 17, y: 45, label: 'Culture\nconditions', kind: 'primary' },
  { id: 'b', x: 39, y: 25, label: 'Protocol\nv2.4', kind: 'primary' },
  { id: 'c', x: 43, y: 67, label: 'Batch 04', kind: 'primary' },
  { id: 'd', x: 65, y: 39, label: 'Protein\nyield', kind: 'result' },
  { id: 'e', x: 80, y: 64, label: 'Purification\nvariance', kind: 'warning' },
  { id: 'f', x: 78, y: 18, label: 'Earlier\nobservation', kind: 'result' },
]
const links = [['a','b'],['a','c'],['b','d'],['c','d'],['d','e'],['f','d']]

function Brand() {
  return <div className="brand-mark"><div className="brand-icon"><Waves size={20} strokeWidth={2.3}/></div><div><div className="brand-name">BioRipple<span>®</span></div><div className="brand-caption">RESEARCH INTELLIGENCE</div></div></div>
}

function Toggle({ value, onChange, label }) {
  return <button className={`toggle ${value ? 'on' : ''}`} aria-label={label} onClick={() => onChange(!value)}><span /></button>
}

function StatCard({ icon: Icon, label, value, delta, tone, delay=0 }) {
  return <motion.div className="stat-card panel" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay, duration: .4 }}>
    <div className={`stat-icon ${tone}`}><Icon size={18}/></div>
    <div className="stat-label">{label}</div>
    <div className="stat-bottom"><div className="stat-value">{value}</div><div className={`stat-delta ${tone}`}>{delta}</div></div>
  </motion.div>
}

function RippleGraph({ selectedNode, setSelectedNode }) {
  const coords = Object.fromEntries(nodes.map(n => [n.id, n]))
  return <div className="graph-canvas">
    <div className="graph-glow glow-one" /><div className="graph-glow glow-two" />
    <svg className="graph-lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-label="Experiment dependency map">
      <defs><linearGradient id="lineGrad"><stop offset="0%" stopColor="#58e1d2" stopOpacity=".55"/><stop offset="100%" stopColor="#6c8cff" stopOpacity=".16"/></linearGradient></defs>
      {links.map(([from,to],i) => <line key={i} x1={coords[from].x} y1={coords[from].y} x2={coords[to].x} y2={coords[to].y} stroke="url(#lineGrad)" strokeWidth=".32" strokeDasharray={i===4 ? '1.4 1.2' : '0'} />)}
      {links.map(([from,to],i) => <circle key={`dot${i}`} r=".65" fill="#58e1d2"><animateMotion dur={`${4+i*.55}s`} repeatCount="indefinite" path={`M ${coords[from].x} ${coords[from].y} L ${coords[to].x} ${coords[to].y}`}/></circle>)}
    </svg>
    {nodes.map((n,i) => <motion.button key={n.id} className={`graph-node ${n.kind} ${selectedNode===n.id?'selected':''}`} style={{left:`${n.x}%`,top:`${n.y}%`}} onClick={() => setSelectedNode(n.id)} initial={{opacity:0,scale:.8}} animate={{opacity:1,scale:1}} transition={{delay:i*.08,type:'spring',stiffness:160,damping:16}} whileHover={{scale:1.06}}>
      <span className="node-dot" /><span className="node-label">{n.label.split('\n').map((s,j)=><React.Fragment key={s}>{j>0&&<br/>}{s}</React.Fragment>)}</span>
    </motion.button>)}
    <div className="graph-legend"><span><i className="legend-dot teal-dot"/>Protocol / input</span><span><i className="legend-dot blue-dot"/>Outcome</span><span><i className="legend-dot amber-dot"/>Review needed</span></div>
  </div>
}


function LandingPage({ onOpenWorkspace }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [openFaq, setOpenFaq] = useState(0)
  const [demoFocus, setDemoFocus] = useState('Yield shift')
  const faqs = [
    { q: 'Does BioRipple prove causality?', a: 'No. BioRipple surfaces candidate relationships between records and makes evidence gaps visible. Every relationship is a hypothesis for a qualified researcher to review.' },
    { q: 'Can I bring in my own experiment records?', a: 'The prototype supports local CSV and JSON imports in the workspace. Data stays in the browser session; a secure shared backend is not connected yet.' },
    { q: 'What kinds of downstream impact can I explore?', a: 'You can trace potential links between protocol versions, process conditions, batches, outcomes, and downstream observations when those links are present in the source records.' },
  ]
  const goTo = (id) => { setMenuOpen(false); document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }) }
  return <div className="landing-shell">
    <header className="landing-nav">
      <a className="landing-brand" href="#top" onClick={(e)=>{e.preventDefault();goTo('top')}}><span className="landing-brand-icon"><Waves size={20}/></span><span>BioRipple<span className="brand-dot">.</span></span></a>
      <button className="landing-menu-toggle" aria-label="Toggle navigation" onClick={()=>setMenuOpen(!menuOpen)}>{menuOpen?<X size={20}/>:<Menu size={20}/>}</button>
      <nav className={menuOpen?'landing-links open':'landing-links'}>
        <button onClick={()=>goTo('platform')}>Platform</button><button onClick={()=>goTo('how-it-works')}>How it works</button><button onClick={()=>goTo('impact')}>Why BioRipple</button><button onClick={()=>goTo('faq')}>FAQ</button>
        <button className="nav-workspace" onClick={onOpenWorkspace}>Open workspace <ArrowUpRight size={15}/></button>
      </nav>
    </header>
    <main id="top">
      <section className="landing-hero">
        <div className="hero-copy">
          <div className="hero-kicker"><span className="hero-kicker-dot"/> RESEARCH, CONNECTED</div>
          <h1>One experiment<br/>can change <span>everything.</span></h1>
          <p className="hero-lede">See the ripple before it becomes a blind spot. BioRipple connects research records, traces potential downstream impacts, and keeps the evidence in view.</p>
          <div className="hero-actions"><button className="hero-primary" onClick={onOpenWorkspace}>Explore the workspace <ArrowUpRight size={17}/></button><button className="hero-secondary" onClick={()=>goTo('how-it-works')}><span className="play-icon"><ArrowRight size={14}/></span> See how it works</button></div>
          <div className="hero-proof"><div className="proof-avatars"><span>R</span><span>M</span><span>A</span></div><div><strong>Built for curious minds.</strong><small>Designed for evidence-led research teams</small></div><div className="proof-separator"/><div className="proof-status"><span/> Prototype ready</div></div>
        </div>
        <motion.div className="hero-art" initial={{opacity:0, y:22, scale:.98}} animate={{opacity:1,y:0,scale:1}} transition={{duration:.7,ease:'easeOut'}}>
          <div className="art-topline"><div><span className="live-pip"/> LIVE RIPPLE MAP</div><span className="art-window"><i/><i/><i/></span></div>
          <div className="art-map">
            <svg viewBox="0 0 560 380" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="landingLine"><stop offset="0%" stopColor="#b9f46a"/><stop offset="100%" stopColor="#9f91ff"/></linearGradient></defs><path d="M90 188 C155 188 154 90 224 90 S302 164 357 164 S430 245 490 245"/><path d="M90 188 C160 188 168 288 244 288 S296 164 357 164"/><path d="M224 90 C270 90 285 42 334 42 S430 95 470 95"/><path d="M357 164 C395 164 406 95 470 95"/></svg>
            <button className={'art-node node-input '+(demoFocus==='Culture conditions'?'focus':'')} onClick={()=>setDemoFocus('Culture conditions')}><span className="art-node-symbol"><FlaskConical size={17}/></span><span><small>INPUT</small><strong>Culture conditions</strong></span><i/></button>
            <button className={'art-node node-protocol '+(demoFocus==='Protocol v2.4'?'focus':'')} onClick={()=>setDemoFocus('Protocol v2.4')}><span className="art-node-symbol"><GitBranch size={17}/></span><span><small>PROTOCOL</small><strong>Version 2.4</strong></span><i/></button>
            <button className={'art-node node-yield '+(demoFocus==='Yield shift'?'focus':'')} onClick={()=>setDemoFocus('Yield shift')}><span className="art-node-symbol"><Activity size={17}/></span><span><small>OUTCOME</small><strong>Yield shift +12%</strong></span><i/></button>
            <button className={'art-node node-risk '+(demoFocus==='Purification variance'?'focus':'')} onClick={()=>setDemoFocus('Purification variance')}><span className="art-node-symbol"><AlertTriangle size={17}/></span><span><small>REVIEW SIGNAL</small><strong>Purification variance</strong></span><i/></button>
            <div className="art-float-card"><span className="float-card-icon"><Sparkles size={15}/></span><div><strong>{demoFocus}</strong><small>Selected relationship · demo data</small></div><span className="float-card-arrow"><ArrowUpRight size={15}/></span></div>
            <div className="art-grid-label label-one">PROCESS LINEAGE</div><div className="art-grid-label label-two">DOWNSTREAM IMPACT</div>
          </div>
          <div className="art-footer"><span><span className="legend-lime"/> Supported link</span><span><span className="legend-violet"/> Candidate relationship</span><span className="art-demo">ILLUSTRATIVE DATA</span></div>
        </motion.div>
        <div className="hero-side-note"><span>01 / 03</span><span className="side-note-line"/><span>FOLLOW THE EVIDENCE</span></div>
      </section>
      <section className="trust-strip"><span>MAKE EVERY RESULT MORE CONNECTED</span><div><span><GitBranch size={16}/> Trace dependencies</span><span><ShieldCheck size={16}/> Keep evidence visible</span><span><Waves size={16}/> Spot downstream ripples</span></div></section>
      <section className="platform-section" id="platform">
        <div className="section-intro"><div className="section-eyebrow">THE PLATFORM / 01</div><h2>Research doesn’t happen<br/>in a straight line.</h2><p>Important context can be scattered across protocols, batches, and notes. BioRipple brings those signals into one connected view.</p></div>
        <div className="feature-grid">
          <motion.article className="feature-card feature-dark" whileHover={{y:-5}} transition={{duration:.2}}><div className="feature-number">01</div><div className="feature-icon lime-icon"><Network size={22}/></div><h3>Map the connections.</h3><p>Explore how inputs, protocol changes, experiments, and outcomes may relate across your research history.</p><div className="mini-graph"><span className="mini-node mn-a"/><span className="mini-node mn-b"/><span className="mini-node mn-c"/><span className="mini-node mn-d"/><span className="mini-link ml-a"/><span className="mini-link ml-b"/><span className="mini-link ml-c"/></div><span className="feature-link" onClick={onOpenWorkspace}>Explore ripple map <ArrowUpRight size={15}/></span></motion.article>
          <motion.article className="feature-card feature-cream" whileHover={{y:-5}} transition={{duration:.2}}><div className="feature-number">02</div><div className="feature-icon violet-icon"><Search size={22}/></div><h3>Find what might matter.</h3><p>Surface potential downstream effects and review signals that could otherwise slip between records.</p><div className="feature-stat"><strong>+12%</strong><span>observed yield shift</span><div className="stat-sparkline"><i/><i/><i/><i/><i/><i/><i/><i/><i/></div></div><span className="feature-link" onClick={onOpenWorkspace}>Inspect a signal <ArrowUpRight size={15}/></span></motion.article>
          <motion.article className="feature-card feature-lime" whileHover={{y:-5}} transition={{duration:.2}}><div className="feature-number">03</div><div className="feature-icon ink-icon"><ShieldCheck size={22}/></div><h3>Keep the evidence honest.</h3><p>See what supports a candidate relationship, what’s missing, and where human review is essential.</p><div className="evidence-mini-visual"><div><Check size={13}/> Source record linked <b>Supported</b></div><div><AlertTriangle size={13}/> Condition not recorded <b>Unknown</b></div></div><span className="feature-link" onClick={onOpenWorkspace}>Review evidence <ArrowUpRight size={15}/></span></motion.article>
        </div>
      </section>
      <section className="how-section" id="how-it-works"><div className="how-heading"><div><div className="section-eyebrow">A CLEARER WAY FORWARD / 02</div><h2>From scattered records<br/>to connected insight.</h2></div><button className="outline-pill" onClick={onOpenWorkspace}>Try the interactive demo <ArrowUpRight size={16}/></button></div><div className="steps-grid"><div className="step-item"><span className="step-index">01</span><div className="step-line"><span/></div><h3>Bring it together.</h3><p>Start with experiment records in CSV or JSON and build a shared picture of your research context.</p></div><div className="step-item"><span className="step-index">02</span><div className="step-line"><span/></div><h3>Follow the ripple.</h3><p>Explore linked conditions, protocol versions, outcomes, and possible downstream observations.</p></div><div className="step-item"><span className="step-index">03</span><div className="step-line"><span/></div><h3>Review the evidence.</h3><p>Separate supported links from unknowns, then bring scientific judgment to the next decision.</p></div></div></section>
      <section className="impact-section" id="impact"><div className="impact-left"><div className="section-eyebrow">BUILT AROUND SCIENTIFIC CARE / 03</div><h2>More context.<br/><span>Fewer blind spots.</span></h2><p>BioRipple is designed to make research relationships easier to inspect—not to replace scientific judgment or turn correlation into causation.</p><button className="hero-primary" onClick={onOpenWorkspace}>Explore BioRipple <ArrowUpRight size={17}/></button></div><div className="impact-right"><div className="impact-quote-mark">“</div><blockquote>Every relationship should come with its evidence—and a clear view of what we still don’t know.</blockquote><div className="impact-quote-footer"><span className="quote-avatar">BR</span><div><strong>The BioRipple principle</strong><small>Evidence first. Human review always.</small></div></div><div className="impact-orbit orbit-one"/><div className="impact-orbit orbit-two"/><div className="impact-orbit orbit-three"/></div></section>
      <section className="faq-section" id="faq"><div className="faq-intro"><div className="section-eyebrow">GOOD QUESTIONS / 04</div><h2>Clarity comes<br/>with context.</h2><p>A few things worth knowing before you dive in.</p></div><div className="faq-list">{faqs.map((faq,i)=><div className={'faq-item '+(openFaq===i?'faq-open':'')} key={faq.q}><button onClick={()=>setOpenFaq(openFaq===i?-1:i)}><span>{faq.q}</span><span className="faq-plus">{openFaq===i?'−':'+'}</span></button><AnimatePresence initial={false}>{openFaq===i&&<motion.div className="faq-answer" initial={{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}}><p>{faq.a}</p></motion.div>}</AnimatePresence></div>)}</div></section>
      <section className="final-cta"><div className="cta-orb"><Waves size={28}/></div><div className="section-eyebrow">YOUR NEXT DISCOVERY STARTS HERE</div><h2>See the bigger picture.</h2><p>Bring your research into context and follow where the evidence leads.</p><button className="cta-button" onClick={onOpenWorkspace}>Enter the workspace <ArrowUpRight size={17}/></button><span className="cta-footnote"><ShieldCheck size={13}/> Demo environment · illustrative data · human review required</span></section>
    </main>
    <footer className="landing-footer"><a className="landing-brand" href="#top" onClick={(e)=>{e.preventDefault();goTo('top')}}><span className="landing-brand-icon"><Waves size={19}/></span><span>BioRipple<span className="brand-dot">.</span></span></a><span>Research intelligence, with evidence in view.</span><span>© 2026 BioRipple · Prototype</span></footer>
  </div>
}

function App() {
  const [view, setView] = useState('landing')
  const [dark, setDark] = useState(true)
  const [active, setActive] = useState('Overview')
  const [mobileNav, setMobileNav] = useState(false)
  const [selectedNode, setSelectedNode] = useState('e')
  const [experiments, setExperiments] = useState(initialExperiments)
  const [search, setSearch] = useState('')
  const [showImport, setShowImport] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const [toast, setToast] = useState('')
  const [preflightChecks, setPreflightChecks] = useState([true, false, true, false])
  const [change, setChange] = useState('Culture condition update')
  const [showEvidence, setShowEvidence] = useState(true)
  const fileRef = useRef(null)

  const filtered = useMemo(() => experiments.filter(e => `${e.name} ${e.id} ${e.type} ${e.status}`.toLowerCase().includes(search.toLowerCase())), [experiments, search])
  const navGroups = [
    { title: 'WORKSPACE', items: [{name:'Overview',icon:Activity},{name:'Ripple Map',icon:Network},{name:'Preflight',icon:ShieldCheck},{name:'Evidence Lab',icon:Lightbulb}] },
    { title: 'LIBRARY', items: [{name:'Experiments',icon:FlaskConical},{name:'Research Notes',icon:FileText}] }
  ]
  const notify = (message) => { setToast(message); window.setTimeout(() => setToast(''), 2800) }
  const changePage = (name) => { setActive(name); setMobileNav(false) }
  const importFile = (file) => {
    if (!file) return
    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const text = String(event.target.result || '')
        if (file.name.endsWith('.json')) {
          const parsed = JSON.parse(text)
          const rows = Array.isArray(parsed) ? parsed : (parsed.experiments || [])
          if (!rows.length) throw new Error('No experiment rows found')
          const mapped = rows.slice(0,100).map((r,i) => ({
            id: r.id || r.experiment_id || `IMPORT-${String(i+1).padStart(3,'0')}`,
            name: r.name || r.title || r.experiment || `Imported experiment ${i+1}`,
            type: r.type || r.category || 'Imported record',
            date: r.date || r.updated_at || 'Just imported',
            status: r.status || 'Imported',
            accent: 'teal',
            detail: r.detail || r.notes || 'Imported from your dataset.'
          }))
          setExperiments(prev => [...mapped, ...prev])
        } else {
          const lines = text.trim().split(/\r?\n/)
          const headers = lines.shift().split(',').map(s=>s.trim().replace(/^"|"$/g,'').toLowerCase())
          const rows = lines.filter(Boolean).map(line => {
            const cells = line.split(',').map(s=>s.trim().replace(/^"|"$/g,''))
            return Object.fromEntries(headers.map((h,i)=>[h,cells[i] || '']))
          })
          if (!rows.length) throw new Error('No data rows found')
          const mapped = rows.slice(0,100).map((r,i)=>({
            id:r.id || r.experiment_id || `IMPORT-${String(i+1).padStart(3,'0')}`,
            name:r.name || r.title || r.experiment || `Imported experiment ${i+1}`,
            type:r.type || r.category || 'Imported record',
            date:r.date || r.updated_at || 'Just imported',
            status:r.status || 'Imported',
            accent:'teal',
            detail:r.detail || r.notes || 'Imported from your dataset.'
          }))
          setExperiments(prev => [...mapped,...prev])
        }
        setShowImport(false)
        notify(`Imported records from ${file.name}`)
      } catch (e) { notify(`Could not read file: ${e.message}. Try CSV or JSON.`) }
    }
    reader.readAsText(file)
  }

  const downloadSample = () => {
    const csv = 'id,name,type,date,status,detail\nEXP-204,Culture optimization — Batch 04,Process study,Today,Reviewed,Growth medium composition updated\nEXP-198,Protein expression baseline,Baseline study,Yesterday,Verified,Reference expression profile\nEXP-176,Purification consistency check,Downstream process,Oct 14,Needs review,Purification variability observed\n'
    const blob = new Blob([csv], {type:'text/csv'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href=url; a.download='bioripple-sample.csv'; a.click(); URL.revokeObjectURL(url)
  }

  if (view === 'landing') return <LandingPage onOpenWorkspace={() => setView('workspace')} />

  return <div className={`app-shell ${dark?'theme-dark':'theme-light'}`}>
    <AnimatePresence>{mobileNav && <motion.div className="mobile-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={()=>setMobileNav(false)}/>}</AnimatePresence>
    <aside className={`sidebar ${mobileNav?'mobile-open':''}`}>
      <div className="sidebar-top"><Brand/><button className="icon-btn sidebar-close" onClick={()=>setMobileNav(false)}><X size={18}/></button></div>
      <button className="workspace-switch" onClick={()=>notify('Workspace switcher is a demo control')}><div className="workspace-avatar">N</div><div className="workspace-info"><strong>Northstar Lab</strong><span>Research workspace</span></div><ChevronDown size={15}/></button>
      <div className="nav-scroll">{navGroups.map(group=><div className="nav-group" key={group.title}><div className="nav-label">{group.title}</div>{group.items.map(item=><button key={item.name} className={`nav-item ${active===item.name?'active':''}`} onClick={()=>changePage(item.name)}><item.icon size={17} strokeWidth={1.8}/><span>{item.name}</span>{item.name==='Evidence Lab'&&<span className="nav-new">NEW</span>}{item.name==='Preflight'&&<span className="nav-count">2</span>}</button>)}</div>)}
      <div className="sidebar-tip"><div className="tip-icon"><Sparkles size={16}/></div><div><strong>Research, connected.</strong><p>Follow the evidence. Explore the ripple.</p><button onClick={()=>changePage('Evidence Lab')}>Explore Evidence Lab <ArrowRight size={13}/></button></div></div>
      </div>
      <div className="sidebar-bottom"><button className="nav-item" onClick={()=>setView('landing')}><ExternalLink size={17}/><span>Back to BioRipple site</span></button><button className="nav-item" onClick={()=>notify('Settings will be available in a future version')}><Settings2 size={17}/><span>Settings</span></button><button className="nav-item" onClick={()=>notify('Help center is a demo control')}><CircleHelp size={17}/><span>Help & feedback</span></button><div className="user-card"><div className="user-avatar">AR</div><div className="user-meta"><strong>Alex Rivera</strong><span>Researcher</span></div><button className="icon-btn" onClick={()=>setShowProfile(!showProfile)}><ChevronDown size={15}/></button>{showProfile&&<div className="profile-popover"><strong>Alex Rivera</strong><span>Demo researcher</span><button onClick={()=>notify('Profile settings are not connected yet')}>Account settings</button><button onClick={()=>notify('Signed out is disabled in demo mode')}>Sign out</button></div>}</div></div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={()=>setMobileNav(true)}><Menu size={19}/></button>
        <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>{active}</strong></div>
        <div className="topbar-actions">
          <label className="search-box"><Search size={16}/><input placeholder="Search experiments..." value={search} onChange={e=>setSearch(e.target.value)}/><kbd>⌘ K</kbd></label>
          <button className="icon-btn theme-button" title={dark?'Switch to light mode':'Switch to dark mode'} onClick={()=>setDark(!dark)}>{dark?<Sun size={17}/>:<Moon size={17}/>}</button>
          <div className="popover-wrap"><button className="icon-btn notification-btn" onClick={()=>setShowNotifications(!showNotifications)}><Bell size={17}/><i/></button>{showNotifications&&<div className="top-popover"><strong>Notifications</strong><div className="notice-row"><span className="notice-dot amber-dot"/><div><b>Review suggested</b><p>Purification consistency check needs attention.</p></div></div><div className="notice-row"><span className="notice-dot teal-dot"/><div><b>Import ready</b><p>Your workspace demo data is available.</p></div></div></div>}</div>
          <div className="top-avatar">AR</div>
        </div>
      </header>

      <div className="page-content">
        <AnimatePresence mode="wait">
          {active==='Overview' && <motion.div key="overview" className="page-view" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-5}} transition={{duration:.22}}>
            <div className="welcome-row"><div><div className="eyebrow"><span className="pulse-dot"/> YOUR RESEARCH, IN CONTEXT</div><h1>Good morning, Alex <span className="wave">✳</span></h1><p className="page-subtitle">See the connections. Understand the impact. Move research forward.</p></div><button className="primary-btn" onClick={()=>setShowImport(true)}><Plus size={17}/> Import experiment <span className="btn-shine"/></button></div>
            <div className="stats-grid">
              <StatCard icon={FlaskConical} label="Experiments tracked" value={String(experiments.length).padStart(2,'0')} delta="+4 this week" tone="teal" delay={.04}/>
              <StatCard icon={GitBranch} label="Potential links" value="18" delta="+6 discovered" tone="blue" delay={.1}/>
              <StatCard icon={AlertTriangle} label="Needs review" value="03" delta="2 high priority" tone="amber" delay={.16}/>
              <StatCard icon={ShieldCheck} label="Evidence coverage" value="84%" delta="+8.2%" tone="teal" delay={.22}/>
            </div>
            <div className="section-heading"><div><h2>Research ripple map</h2><p>Explore how experiments, conditions and outcomes connect.</p></div><button className="subtle-btn" onClick={()=>changePage('Ripple Map')}>Explore full map <ArrowRight size={15}/></button></div>
            <div className="overview-grid">
              <section className="panel map-panel"><div className="panel-heading"><div className="panel-title"><div className="small-icon teal"><Network size={16}/></div><div><h3>Experiment dependencies</h3><p>Last analyzed just now <span className="live-mark"/></p></div></div><button className="icon-btn" onClick={()=>changePage('Ripple Map')}><ExternalLink size={16}/></button></div><RippleGraph selectedNode={selectedNode} setSelectedNode={setSelectedNode}/><div className="map-footer"><div><span className="tiny-label">SELECTED NODE</span><strong>{nodes.find(n=>n.id===selectedNode)?.label.replace('\n',' ')}</strong></div><button className="text-btn" onClick={()=>changePage('Ripple Map')}>View dependencies <ArrowRight size={14}/></button></div></section>
              <section className="panel insight-panel"><div className="panel-heading"><div className="panel-title"><div className="small-icon amber"><Sparkles size={16}/></div><div><h3>Signal detected</h3><p>Potential connection · 2 min ago</p></div></div><span className="status-pill status-review">Review</span></div><div className="insight-feature"><div className="insight-orb"><Activity size={25}/><span/></div><div><div className="insight-kicker">POTENTIAL DOWNSTREAM IMPACT</div><h3>Yield shift may connect to purification variance</h3><p>Two records share a process lineage, but a key condition is not documented in the later batch.</p></div></div><div className="evidence-mini"><div className="evidence-line"><span className="evidence-check"><Check size={12}/></span><span>Shared process lineage detected</span><span className="evidence-state">Supported</span></div><div className="evidence-line"><span className="evidence-warn"><AlertTriangle size={12}/></span><span>Condition record incomplete</span><span className="evidence-state warn">Unknown</span></div></div><button className="wide-btn" onClick={()=>changePage('Evidence Lab')}>Inspect evidence <ArrowRight size={15}/></button><div className="disclaimer"><ShieldCheck size={13}/> Hypothesis only · Human review required</div></section>
            </div>
            <div className="section-heading recent-heading"><div><h2>Recent experiments</h2><p>Your latest activity across the workspace.</p></div><button className="subtle-btn" onClick={()=>changePage('Experiments')}>View all <ArrowRight size={15}/></button></div>
            <div className="panel experiment-table">
              <div className="table-head"><span>EXPERIMENT</span><span>TYPE</span><span>LAST UPDATED</span><span>STATUS</span><span/></div>
              {filtered.slice(0,4).map((exp,i)=><motion.div className="table-row" key={exp.id} initial={{opacity:0,x:-6}} animate={{opacity:1,x:0}} transition={{delay:i*.04}}><div className="exp-name"><div className={`exp-icon ${exp.accent}`}><FlaskConical size={16}/></div><div><strong>{exp.name}</strong><span>{exp.id}</span></div></div><span className="table-type">{exp.type}</span><span className="table-date"><Clock3 size={13}/>{exp.date}</span><span><Status status={exp.status}/></span><button className="row-more" onClick={()=>notify(exp.detail)} aria-label={`Details for ${exp.name}`}><ArrowRight size={15}/></button></motion.div>)}
              {filtered.length===0&&<div className="empty-state">No experiments match “{search}”. Try another search.</div>}
            </div>
            <div className="footer-note"><span>BioRipple Research Intelligence <span className="footer-sep">·</span> Demo workspace</span><span><span className="pulse-dot"/> All systems operational</span></div>
          </motion.div>}

          {active==='Ripple Map' && <motion.div key="map" className="page-view" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-5}}><PageHeader eyebrow="TRACE THE CONNECTIONS" title="Ripple Map" subtitle="Explore how changes can propagate through your experimental work." action={<button className="subtle-btn" onClick={()=>notify('Map export is planned for a future version')}><Download size={15}/> Export map</button>}/><div className="panel map-page-panel"><div className="map-toolbar"><div><span className="live-mark"/> <span>6 nodes</span><span className="toolbar-sep">·</span><span>6 connections</span></div><button className="filter-btn" onClick={()=>setShowEvidence(!showEvidence)}><Filter size={14}/>{showEvidence?'Evidence overlay on':'Evidence overlay off'}</button></div><RippleGraph selectedNode={selectedNode} setSelectedNode={setSelectedNode}/><div className="selected-detail"><div className="selected-detail-icon"><CircleDot size={18}/></div><div className="selected-detail-copy"><span className="tiny-label">SELECTED RECORD</span><h3>{nodes.find(n=>n.id===selectedNode)?.label.replace('\n',' ')}</h3><p>{selectedNode==='e'?'Potential downstream effect flagged for review. This is a hypothesis, not a causal conclusion.':selectedNode==='d'?'Outcome record connected to culture conditions and batch lineage.':'Connected record in the illustrative research dataset.'}</p></div><button className="subtle-btn" onClick={()=>changePage('Evidence Lab')}>Inspect evidence <ArrowRight size={14}/></button></div></div><div className="callout"><Lightbulb size={17}/><div><strong>How to read this map</strong><p>Connections represent recorded dependencies or candidate relationships. Dashed links indicate a relationship that needs review. A connection alone does not establish causation.</p></div></div></motion.div>}

          {active==='Preflight' && <motion.div key="preflight" className="page-view" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-5}}><PageHeader eyebrow="BEFORE YOU BEGIN" title="Experiment preflight" subtitle="Check a study plan for gaps that could make results hard to interpret." action={<button className="primary-btn" onClick={()=>notify('Preflight review complete — see the checklist below.')}><ShieldCheck size={16}/> Run checks</button>}/><div className="preflight-layout"><section className="panel preflight-main"><div className="panel-heading"><div className="panel-title"><div className="small-icon teal"><ShieldCheck size={16}/></div><div><h3>Plan readiness checklist</h3><p>Example checklist · edit before using in real research</p></div></div><span className="status-pill status-review">{preflightChecks.filter(Boolean).length}/4 complete</span></div>{['Controls and comparison groups are documented','Relevant variables and sample conditions are recorded','Protocol version and reagent batch are traceable','Analysis criteria are defined before reviewing outcomes'].map((item,i)=><label className="check-row" key={item}><input type="checkbox" checked={preflightChecks[i]} onChange={()=>setPreflightChecks(p=>p.map((v,j)=>i===j?!v:v))}/><span className="fake-check">{preflightChecks[i]&&<Check size={13}/>}</span><span className={preflightChecks[i]?'checked-text':''}>{item}<small>{['Required to interpret comparisons','Supports reproducibility','Helps trace potential changes','Reduces post-hoc interpretation'][i]}</small></span><span className={`check-tag ${preflightChecks[i]?'done':'todo'}`}>{preflightChecks[i]?'Recorded':'Review'}</span></label>)}<div className="preflight-progress"><div><span>Checklist progress</span><strong>{Math.round(preflightChecks.filter(Boolean).length/4*100)}%</strong></div><div className="progress-track"><span style={{width:`${preflightChecks.filter(Boolean).length/4*100}%`}}/></div></div></section><aside className="panel preflight-aside"><div className="aside-orb"><ShieldCheck size={26}/></div><h3>Build confidence before the first run.</h3><p>This checklist highlights documentation and design questions to review with your research team. It does not certify that an experiment is scientifically valid.</p><div className="aside-rule"/><div className="mini-stat"><span>Checklist completion</span><strong>{preflightChecks.filter(Boolean).length} of 4</strong></div><div className="mini-stat"><span>Outstanding items</span><strong className="amber-text">{4-preflightChecks.filter(Boolean).length}</strong></div></aside></div></motion.div>}

          {active==='Evidence Lab' && <motion.div key="evidence" className="page-view" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-5}}><PageHeader eyebrow="EVIDENCE BEFORE ASSUMPTIONS" title="Evidence Lab" subtitle="Review why a relationship was flagged, what supports it, and what remains unknown." action={<button className="subtle-btn" onClick={()=>setShowEvidence(!showEvidence)}><Settings2 size={15}/> {showEvidence?'Hide details':'Show details'}</button>}/><div className="evidence-layout"><section className="panel evidence-main"><div className="evidence-banner"><div className="banner-icon"><Sparkles size={18}/></div><div><span className="tiny-label">CANDIDATE RELATIONSHIP · DEMO DATA</span><h3>Culture condition change ↔ purification variance</h3><p>A possible connection worth reviewing. No causal claim is made.</p></div><span className="status-pill status-review">Unverified</span></div>{showEvidence&&<><div className="evidence-section"><h4><CheckCircle2 size={16}/> Supporting records</h4><div className="source-card"><div className="source-file"><FileText size={17}/></div><div className="source-copy"><strong>EXP-204 · Culture optimization — Batch 04</strong><p>Records a change to growth medium composition and an observed yield shift.</p><span>Source: imported demo record</span></div><span className="source-score">Direct</span></div><div className="source-card"><div className="source-file blue"><FileText size={17}/></div><div className="source-copy"><strong>EXP-176 · Purification consistency check</strong><p>Records variability in a downstream process; the relevant condition is not documented in this example.</p><span>Source: imported demo record</span></div><span className="source-score amber-text">Incomplete</span></div></div><div className="evidence-section"><h4><AlertTriangle size={16}/> What remains unknown</h4><div className="unknown-box"><ul><li>Whether the batches used comparable starting material.</li><li>Whether the missing process condition explains the observed variance.</li><li>Whether other variables changed at the same time.</li></ul></div></div></>}</section><aside className="panel evidence-side"><div className="small-icon amber"><Lightbulb size={16}/></div><h3>What could strengthen this hypothesis?</h3><p>Review the original batch records and compare the relevant conditions before drawing a conclusion.</p><div className="side-step"><span>01</span><div><strong>Verify the record</strong><p>Confirm the process lineage.</p></div></div><div className="side-step"><span>02</span><div><strong>Fill the gap</strong><p>Find the missing condition data.</p></div></div><div className="side-step"><span>03</span><div><strong>Ask an expert</strong><p>Decide whether a controlled follow-up is needed.</p></div></div><button className="wide-btn" onClick={()=>notify('Review note saved in this demo session.')}>Mark for human review <ArrowRight size={14}/></button></aside></div></motion.div>}

          {(active==='Experiments'||active==='Research Notes') && <motion.div key={active} className="page-view" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-5}}><PageHeader eyebrow="YOUR RESEARCH LIBRARY" title={active} subtitle={active==='Experiments'?'Browse imported experiment records in this demo workspace.':'A focused space for evidence notes and research observations.'} action={<button className="primary-btn" onClick={()=>setShowImport(true)}><Upload size={16}/> Import data</button>}/>{active==='Experiments'?<div className="panel library-list">{filtered.map(e=><div className="library-item" key={e.id}><div className={`exp-icon ${e.accent}`}><FlaskConical size={17}/></div><div className="library-copy"><strong>{e.name}</strong><p>{e.detail}</p><span>{e.id} <span className="footer-sep">·</span> {e.type}</span></div><Status status={e.status}/></div>)}{filtered.length===0&&<div className="empty-state">No matching records.</div>}</div>:<div className="panel notes-empty"><div className="empty-illustration"><FileText size={27}/></div><h3>Your evidence notes start here.</h3><p>Import research records or use the Evidence Lab to review a candidate relationship. Notes are a demo interface and are not persisted to a server.</p><button className="primary-btn" onClick={()=>changePage('Evidence Lab')}>Open Evidence Lab <ArrowRight size={15}/></button></div>}</motion.div>}
        </AnimatePresence>
      </div>
    </main>

    <AnimatePresence>{showImport&&<motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onMouseDown={e=>e.target===e.currentTarget&&setShowImport(false)}><motion.div className="import-modal" initial={{opacity:0,y:16,scale:.98}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:8,scale:.98}} transition={{duration:.2}}><div className="modal-top"><div className="modal-symbol"><Upload size={19}/></div><button className="icon-btn" onClick={()=>setShowImport(false)}><X size={18}/></button></div><h2>Bring your research into context.</h2><p>Import a CSV or JSON file to add experiment records to this browser session. Files are processed locally by this demo; no server upload is configured.</p><button className="dropzone" onClick={()=>fileRef.current?.click()}><div className="upload-symbol"><Upload size={20}/></div><strong>Click to choose a file</strong><span>CSV or JSON · up to 100 records displayed</span><input ref={fileRef} type="file" accept=".csv,.json,text/csv,application/json" hidden onChange={e=>importFile(e.target.files?.[0])}/></button><div className="modal-divider"><span>OR START WITH</span></div><button className="sample-btn" onClick={()=>{setExperiments(initialExperiments);setShowImport(false);notify('Sample experiment records restored.')}}><div className="sample-icon"><FlaskConical size={17}/></div><div><strong>Sample research dataset</strong><span>Restore the built-in demo records</span></div><ArrowRight size={16}/></button><button className="download-sample" onClick={downloadSample}><Download size={14}/> Download sample CSV template</button><div className="privacy-note"><ShieldCheck size={14}/> Local demo only · Don't upload sensitive or identifiable research data.</div></motion.div></motion.div>}</AnimatePresence>
    <AnimatePresence>{toast&&<motion.div className="toast" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} exit={{opacity:0,y:8}}><CheckCircle2 size={17}/>{toast}</motion.div>}</AnimatePresence>
  </div>
}

function Status({status}) {
  const cls = status==='Verified'?'verified':status==='Reviewed'?'reviewed':status==='Imported'?'imported':'review'
  return <span className={`status-pill status-${cls}`}><span/>{status}</span>
}

function PageHeader({eyebrow,title,subtitle,action}) {
  return <div className="welcome-row page-header"><div><div className="eyebrow"><span className="pulse-dot"/>{eyebrow}</div><h1>{title}</h1><p className="page-subtitle">{subtitle}</p></div>{action}</div>
}

export default App
