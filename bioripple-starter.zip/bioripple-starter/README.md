# BioRipple — Research Intelligence

A responsive React + Vite front-end prototype for BioRipple, with a bold public landing page and an interactive evidence-linked biotech research workspace. The visual direction takes broad inspiration from modern creative-agency websites while retaining BioRipple’s own layout, content, and identity.

## Features in this starter

- Editorial marketing landing page with responsive navigation, interactive ripple-map preview, feature sections, FAQ accordion, and calls to action
- Interactive workspace accessible from the landing page, with a return link to the public site
- Distinct BioRipple palette: deep botanical charcoal, chartreuse, warm paper, and lavender accents
- Dark and light theme switch
- Responsive sidebar navigation
- Animated experiment dependency map
- Demo overview metrics and experiment list
- CSV / JSON import processed locally in the browser
- Preflight checklist with interactive state
- Evidence review panel with explicit uncertainty labels
- Toast notifications, modals, hover and page transitions
- Sample CSV download
- GitHub Pages deployment workflow

## Run locally

1. Install Node.js 20 or newer.
2. Unzip this project and open the folder in a terminal.
3. Run:

```bash
npm install
npm run dev
```

4. Open the local URL printed by Vite.

To test a production build:

```bash
npm run build
npm run preview
```

## Publish on GitHub Pages

1. Create a new GitHub repository named `bioripple` (or another name).
2. Upload all files from this folder, including `.github/workflows/deploy.yml`.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **GitHub Actions**.
5. Push to the `main` branch. The workflow will build and publish the site.
6. Find the live URL under **Settings → Pages → Visit site**.

If you deploy to a project repository, `base: './'` in `vite.config.js` helps Vite use relative asset paths.

## Import format

CSV headers supported include `id`, `name` (or `title` / `experiment`), `type`, `date`, `status`, and `detail` (or `notes`).

Example:

```csv
id,name,type,date,status,detail
EXP-101,Cell viability baseline,Validation study,2026-10-12,Verified,Reference condition
```

JSON may be an array of records or an object with an `experiments` array.

## Important limitations

This is a front-end demo, not a validated scientific analysis tool. Metrics and graph relationships are illustrative demo data. The imported records are held in React state and are not saved to a database; refreshing the page resets them. CSV parsing in this starter is intentionally simple and does not support every quoted-comma edge case. No AI model, causal inference, backend, authentication, or cloud data storage is connected.

Do not upload confidential, identifiable, or unpublished research data. Treat all generated relationships as hypotheses requiring expert review.

## Suggested next build steps

1. Add a proper CSV parser such as Papa Parse.
2. Define an explicit schema for experiments, protocol versions, samples, outcomes, and dependency edges.
3. Replace demo graph edges with edges computed from verified imported data.
4. Add tests for the impact-analysis rules.
5. If needed, connect a secure backend with authentication, access controls, audit logging, and encryption.
6. Only add an LLM after you have reliable source references and guardrails for evidence-backed explanations.
